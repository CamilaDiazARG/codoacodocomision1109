
package actividadjava;

import java.util.Scanner;

public class actividadjava {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in) ; 
        System.out.println("Ingrese su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese su apellido:");
        String apellido = scanner.nextLine();
        System.out.println("Ingrese su edad:");
        String edad = scanner.nextLine();
        System.out.println("Ingrese su hobbie:");
        String hobbie = scanner.nextLine();
        System.out.println("Ingrese su editor de código preferido:");
        String editor = scanner.nextLine();
        System.out.println("Ingrese el sistema opetarivo que utiliza:");
        String sistema = scanner.nextLine();
        
     
        
        System.out.println("Bienvenido al sistema");
        System.out.println("Los datos ingresados son:");
        System.out.println("Tu nombre: " + nombre + " " + apellido);
        System.out.println("Tu edad: " + edad);
        System.out.println("Tu hobbie: " + hobbie);
        System.out.println("Tu editor de código preferido: " + editor);
        System.out.println("El sitema operatido que usas es: " + sistema);
        
    }

    
}

